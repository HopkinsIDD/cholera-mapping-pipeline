suppressPackageStartupMessages(library(stars))
bcsd_obs
L7_ETMs
if (require(starsdata)) {
	print(stars_sentinel2)
}
