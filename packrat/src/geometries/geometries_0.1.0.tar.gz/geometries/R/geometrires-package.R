#' @useDynLib geometries, .registration = TRUE
#' @importFrom Rcpp sourceCpp
NULL
