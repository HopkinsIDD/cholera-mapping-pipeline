#
# sf <- mapdeck::roads
#
# df <- sf_to_df(sf, fill = TRUE)
#
# head( df )
#
# sf2 <- sf_linestring(
#   obj = df
#   , x = "x"
#   , y = "y"
#   , linestring_id = "linestring_id"
#   , keep = TRUE
#   , list_columns = c("EZI_RDNAME", "ROAD_NAME", "sfg_id", "TO_UFI")
# )
